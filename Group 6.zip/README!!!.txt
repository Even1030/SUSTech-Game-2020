未做任何商业用途
所有内容均收集于互联网,如果有不妥之处,敬请谅解。如有侵权内容,请联系我们删除。
（It has not been used for any commercial purpose. ）
（All contents of the collection site on the Internet, if there is nothing wrong with it over. For infringement, please contact us deleted. ）

1. For poker.zip
plz read the Texas-AI.ppt or link to the author: https://download.csdn.net/download/qq_43126760/11173538
2. For holdem_calc-master.zip
plz read the Texas-AI-final.ppt or link to the author: https://github.com/souzatharsis/holdem_calc
